package com.moodup.movies.state

enum class LogoutState {
    LOGOUT_SUCCESS
}