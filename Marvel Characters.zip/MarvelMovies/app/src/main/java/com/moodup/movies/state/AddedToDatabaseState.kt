package com.moodup.movies.state

enum class AddedToDatabaseState {
    ADDED_SUCCESS,
    REMOVED_SUCCESS,
    NO_DOCUMENT,
    FAILURE
}