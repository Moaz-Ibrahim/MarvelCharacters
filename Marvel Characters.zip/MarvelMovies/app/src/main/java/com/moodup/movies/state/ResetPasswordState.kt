package com.moodup.movies.state

enum class ResetPasswordState {
    RESET_SUCCESS,
    RESET_FAILURE,
    EMPTY_EMAIL
}