package com.moodup.movies.model

data class Thumbnail(
    val extension: String,
    val path: String
){
    constructor() : this("","")
}