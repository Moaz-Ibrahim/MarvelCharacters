package com.moodup.movies.ui.home.adapter.viewholder.movies

import android.view.View
import com.moodup.movies.ui.home.adapter.viewholder.BaseViewHolder

class FooterViewHolder(itemView : View) : BaseViewHolder(itemView){
}